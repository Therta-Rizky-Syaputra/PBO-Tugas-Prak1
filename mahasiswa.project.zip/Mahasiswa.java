public class Mahasiswa {
    public static void main(String[] args) {
        MahasiswaBeraksi mhs = new MahasiswaBeraksi();

        mhs.membaca();
        
        mhs.nyontek();
        
        mhs.modifikasi();
    }
}
