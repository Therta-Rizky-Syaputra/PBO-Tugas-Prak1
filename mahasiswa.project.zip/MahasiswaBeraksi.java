public class MahasiswaBeraksi {
    
    public void membaca() {
        System.out.println("Mahasiswa sedang membaca buku.");
    }

    public void nyontek() {
        System.out.println("Mahasiswa sedang menyontek.");
    }

    public void modifikasi() {
        System.out.println("Mahasiswa sedang memodifikasi tugas.");
    }
}
