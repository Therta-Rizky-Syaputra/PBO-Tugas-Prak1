public class DemoNilai {
    public static void main(String[] args) {
        Nilai n = new Nilai();

        n.nim = "123456";
        n.nama = "Budiawan";
        n.absen = 80;
        n.tugas = 85;
        n.uts = 75;
        n.uas = 95;
        n.CetakNilai();
    }
}
